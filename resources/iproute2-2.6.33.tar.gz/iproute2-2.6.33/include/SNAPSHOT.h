static const char SNAPSHOT[] = "100224";
